#!/data/data/com.termux/files/usr/bin/bash
# Ambil UI terbaru dari Download -> www/index.html -> push -> APK baru dibangun otomatis.
cd "$(dirname "$0")" || exit 1
N=$(ls -t /sdcard/Download/mw_studio_dsp_ui*.html 2>/dev/null | head -1)
[ -z "$N" ] && { echo "Tidak ada file mw_studio_dsp_ui*.html di Download"; exit 1; }
cp "$N" www/index.html && echo "UI dipakai: $(basename "$N")"
git add -A && git commit -m "ui $(date +%F_%H%M)" && git push
echo "Selesai. APK baru siap sekitar 6-10 menit lagi di halaman Releases."

// Jembatan tipis: halaman UI memanggil window.NativeBle (hanya ada di dalam APK).
// Di Chrome biasa objek ini tidak dibuat, jadi UI otomatis memakai Web Bluetooth.
import { Capacitor } from '@capacitor/core';
import { BleClient } from '@capacitor-community/bluetooth-le';
import { StatusBar } from '@capacitor/status-bar';

if (Capacitor.isNativePlatform()) {
  window.NativeBle = {
    init: () => BleClient.initialize({ androidNeverForLocation: true }),
    request: svc => BleClient.requestDevice({ services: [svc] }),
    connect: (id, onLost, timeout) => BleClient.connect(id, onLost, { timeout }),
    disconnect: id => BleClient.disconnect(id),
    notify: (id, svc, chr, cb) => BleClient.startNotifications(id, svc, chr, cb),
    write: (id, svc, chr, bytes) =>
      BleClient.write(id, svc, chr, new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)),
    hideStatusBar: () => StatusBar.hide()
  };
}

// Dijalankan CI setelah `cap add android`: layar landscape, izin BLE, tanda tangan tetap, versionCode naik.
import fs from 'node:fs';
const run = process.env.GITHUB_RUN_NUMBER || '1';
const warn = m => console.log('::warning::' + m);

const mp = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(mp, 'utf8');
if (!m.includes('xmlns:tools')) m = m.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ');
if (!m.includes('screenOrientation')) m = m.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
if (!m.includes('neverForLocation')) m = m.replace('</manifest>',
  '    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" tools:targetApi="s" />\n' +
  '    <uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />\n</manifest>');
fs.writeFileSync(mp, m);

const gp = 'android/app/build.gradle';
let g = fs.readFileSync(gp, 'utf8');
g = g.replace(/versionCode\s+\d+/, 'versionCode ' + run).replace(/versionName\s+"[^"]*"/, 'versionName "1.' + run + '"');
if (/buildTypes\s*\{/.test(g) && !g.includes('signingConfigs.mwdsp')) {
  g = g.replace(/buildTypes\s*\{/,
`signingConfigs {
        mwdsp {
            storeFile rootProject.file("../mwdsp.keystore")
            storeType "pkcs12"
            storePassword "mwdsp123"
            keyAlias "mwdsp"
            keyPassword "mwdsp123"
        }
    }
    buildTypes {
        debug { signingConfig signingConfigs.mwdsp }`);
} else {
  warn('buildTypes tidak ditemukan: APK tetap jadi tapi kuncinya acak (update harus uninstall dulu)');
}
fs.writeFileSync(gp, g);
console.log('patch-android selesai, versionCode =', run);

# MW DSP – APK remote (BLE)

Aplikasi ini hanya membungkus UI (`www/index.html`) dan memakai Bluetooth native Android.
Pertama kali: pilih MW-DSP sekali. Setelah itu aplikasi langsung tersambung sendiri.

## Sekali saja: kirim proyek ke GitHub (dari Termux)
1. Di browser, buat repo baru di github.com (nama bebas, mis. `mw-dsp`, pilih **Private**).
2. Buat token: GitHub > Settings > Developer settings > Personal access tokens > Tokens (classic)
   > centang `repo` dan `workflow`. Salin tokennya.
3. Di Termux, di dalam folder proyek ini:
   ```
   pkg install git
   git init -b main
   git add -A
   git commit -m "awal"
   git remote add origin https://github.com/USERNAME/mw-dsp.git
   git push -u origin main
   ```
   Saat diminta password, tempel token tadi.
4. Buka tab **Actions** di repo, tunggu build selesai (sekitar 6-10 menit, centang hijau).

## Pasang di HP
Buka tautan ini di Chrome HP (ganti USERNAME dan nama repo; kalau repo private, masuk dulu ke GitHub di Chrome):
`https://github.com/USERNAME/mw-dsp/releases/latest/download/MW-DSP.apk`
Izinkan "pasang dari sumber ini" kalau diminta, lalu pasang. Saat pertama dibuka, izinkan Bluetooth ("Perangkat sekitar").

## Update UI (satu perintah)
Unduh file `mw_studio_dsp_ui_*.html` terbaru, lalu di Termux di folder proyek:
```
./ui.sh
```
Perintah itu menyalin UI terbaru jadi `www/index.html`, push ke GitHub, dan APK baru dibangun sendiri.
Pasang ulang dari tautan yang sama (tanda tangan tetap, jadi tidak perlu uninstall).

## Catatan
- Kunci tanda tangan `mwdsp.keystore` ikut di repo supaya update bisa menimpa. Karena itu pakai repo **Private**.
- Layar dipaksa landscape dan tetap menyala selama aplikasi terbuka.
- Kalau ikon default Capacitor yang muncul, langkah ikon di workflow gagal; aplikasi tetap berfungsi.
